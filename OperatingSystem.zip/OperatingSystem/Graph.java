/*
//////////////////////////////////////////////////////////
MEMBER LIST
1. TAN SIN ZHUNG (1191100281)
2. LEONG YI HONG (1191100292)
//////////////////////////////////////////////////////////*/

public class Graph{
    private String processName;
    private int time;

    public Graph(String processName, int time){
        this.processName = processName;
        this.time = time;
    }
    public String getProcess(){
        return processName;
    }
    public int getTime(){
        return time;
    }

    public String toString(){
        return processName +" , time => " + time;
    }
}